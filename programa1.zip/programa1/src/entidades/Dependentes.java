package entidades;

public class Dependentes {

    private String nome;
    private int idade;
    private Empregados empregado_Pai;

    public Dependentes() {

    }

    public Dependentes(String nome,int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() { return nome; }

    public void setNome(String nome) { this.nome = nome; }

    public int getIdade() { return idade; }

    public void setIdade(int idade) { this.idade = idade; }

    public Empregados getEmpregado_Pai() { return empregado_Pai; }

    public void setEmpregado_Pai(Empregados empregado_Pai) { this.empregado_Pai = empregado_Pai; }

}
