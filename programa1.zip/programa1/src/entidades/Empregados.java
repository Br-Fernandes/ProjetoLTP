package entidades;

public class Empregados {

    //nome do empregado, idade do empregado, quantidade de dependentes,
    //nomes dos dependentes, idades dos dependentes, salario

    //a) Ler dados dos empregados. Os dados são fornecidos pelo usuário através da entrada padrão
    //(teclado).

    //b) Não se sabe quantos empregados existem. Desta forma o programa deve terminar quando o
    //usuário digitar “xxx” ou “XXX” no nome do empregado.

    //c) Gerar um arquivo texto (arquivo1) contendo os dados fornecidos pelo usuário. Esse arquivo
    //texto será aberto e lido programa especificado no próximo item (Programa 2)

    private String nome;
    private int idade;
    private Dependentes[] dependentes;
    private double salario;

    public Empregados() {

    }

    public Empregados(String nome, int idade, Dependentes[] dependentes, double salario) {
        setIdade(idade);
        setNome(nome);
        setDependentes(dependentes);
        setSalario(salario);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Dependentes[] getDependentes() { return dependentes; }

    public void setDependentes(Dependentes[] dependentes) { this.dependentes = dependentes; }

}