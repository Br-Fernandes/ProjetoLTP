import entidades.Empregados;
import vizualizacao.InterfaceGrafica;

import javax.swing.*;

public class Main {



    public static void main(String[] args) {

        InterfaceGrafica.getEmpregados();

    }

}