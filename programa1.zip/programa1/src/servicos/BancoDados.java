package servicos;

import entidades.Dependentes;
import entidades.Empregados;

import javax.swing.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class BancoDados {

    private File file = new File("");

    private String pt = file.getAbsolutePath();

    private File arquivoAtual = new File(pt.replace("programa1", "arquivo1.csv"));

    public void escreverNoBanco(String frase) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(this.arquivoAtual, true))) {

            bw.write(frase);

        }catch (IOException e) {

        }

    }

    public void novaLinha() {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(this.arquivoAtual, true))) {

            bw.newLine();

        } catch (IOException e) {

        }

    }

    public void CadastrarEmpregadoBD(Empregados empregados) {

        escreverNoBanco(empregados.getNome()); escreverNoBanco(","); escreverNoBanco(String.valueOf(empregados.getIdade())); escreverNoBanco(",");
        escreverNoBanco(String.valueOf(empregados.getSalario())); escreverNoBanco(",");

        for (Dependentes dep : empregados.getDependentes()) {

            escreverNoBanco(dep.getNome()); escreverNoBanco(","); escreverNoBanco(String.valueOf(empregados.getIdade())); escreverNoBanco(",");

        }

        novaLinha();

    }

}
