package vizualizacao;

import entidades.Dependentes;
import entidades.Empregados;
import servicos.BancoDados;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InterfaceGrafica {

    public static void getEmpregados() {

        JTextField nome = new JTextField();
        JTextField idade = new JTextField();
        JTextField salario = new JTextField();

        Object[] campos = {
                "Nome do Empregado: ", nome,
                "Idade do Empregado: ", idade,
                "Salário do Empregado: ", salario
        };

        Empregados emp = new Empregados();
        BancoDados bd = new BancoDados();

        while (nome.getText().toLowerCase() != "xxx") {

            int Cadastro = JOptionPane.showConfirmDialog(null, campos, "Cadatro de Empregados", JOptionPane.OK_CANCEL_OPTION);

            if (nome.getText().toLowerCase().equals("xxx")) {

                break;

            } else {

                Dependentes[] dependentes = getDependentes();

                emp = new Empregados(nome.getText(), Integer.parseInt(idade.getText()), dependentes, Double.parseDouble(salario.getText()));

                bd.CadastrarEmpregadoBD(emp);

            }

            nome.setText("");
            idade.setText("");
            salario.setText("");

        }

    }

    public static Dependentes[] getDependentes() {

        int qtd_Dependentes = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o número de dependentes?", "Cadastro de Dependentes", JOptionPane.INFORMATION_MESSAGE));

        Dependentes[] deps = new Dependentes[qtd_Dependentes];

        JTextField nome = new JTextField();
        JTextField idade = new JTextField();

        Object[]  campos = {
                "Nome do Dependente: ", nome,
                "Idade do Dependente:", idade
        };

        for (int i = 0; i < qtd_Dependentes; i++ ) {

            JOptionPane.showConfirmDialog(null,campos,"Cadastro de Dependentes",JOptionPane.OK_CANCEL_OPTION);
            deps[i] = new Dependentes(nome.getText(),Integer.parseInt(idade.getText()));
            nome.setText("");
            idade.setText("");

        }

        return deps;

    }

}