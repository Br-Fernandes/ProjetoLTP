package servico;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class BancoDados {

    File file = new File("");

    private String pt = file.getAbsolutePath();

    File arquivoAtual = new File(pt.replace("programa2","arquivo1.csv"));

    public ArrayList<String> LerArquivo() {

        ArrayList<String> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(this.arquivoAtual))){

            String read = br.readLine();

            while (read != null ) {

                lista.add(read);
                read = br.readLine();

            }

        } catch (IOException e) {

        }

        return lista;

    }

    public String[][]  PegandoInformacoes() {

        ArrayList<String> Leitura_BD = LerArquivo();

        int qtd = Leitura_BD.size();

        String[][] Tabela = new String[qtd][3];

        String[] nome_emp = new String[qtd];
        String[] nome_dep = new String[qtd];
        String[] idade_dep = new String[qtd];

        String[] informacoes;

        int p = 0;

        for (String linha : Leitura_BD) {

            informacoes = linha.split(",");
            nome_emp[p] = informacoes[0];

            for (int i = 0; i < informacoes.length; i++){

                if (i > 2) {

                    try {

                        if (Integer.parseInt(informacoes[i]) > 40) {

                            nome_dep[p] = informacoes[i-1];
                            idade_dep[p] = informacoes[i];

                        }

                    }catch (NumberFormatException e){

                    }

                }

            }

            p++;

        }

        for (int i = 0; i < qtd; i++) {

            Tabela[i][0] = nome_emp[i];
            Tabela[i][1] = nome_dep[i];
            Tabela[i][2] = idade_dep[i];

        }

        return Tabela;

    }

}
