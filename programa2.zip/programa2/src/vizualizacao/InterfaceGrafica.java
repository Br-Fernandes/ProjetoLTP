package vizualizacao;

import servico.BancoDados;

import javax.swing.*;

public class InterfaceGrafica {

    public static void mostrarTabela() {

        BancoDados bd = new BancoDados();

        String[][] tabela = bd.PegandoInformacoes();

        Object[] colunas = {"Empregado", "Dependente", "Idade"};

        JTable tb = new JTable(tabela, colunas);

        JOptionPane.showMessageDialog(null,new JScrollPane(tb), "Dados Gerais",JOptionPane.PLAIN_MESSAGE);

    }

}
