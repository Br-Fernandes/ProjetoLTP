package aplicacao;

import servico.BancoDados;
import vizualizacao.InterfaceGrafica;

public class Main {

    //Ler os dados do arquivo texto gerado no item anterior (arquivo1) inserindo os empregados
    //em um vetor de empregados. Se já houver empregados no vetor, eles são removidos e os que
    //estão no arquivo1 são inseridos.

    //b) Imprimir uma listagem contendo os nomes dos empregados e seus dependentes que possuem
    //idades acima de 40 anos.

    //c) Atualizar o salário de todos os empregados com aumento de 5% no valor do salário.

    //d) Identifique os empregados com a maior e a menor média de idades entre seus integrantes
    //(média da idade do empregado e dos seus dependentes).

    //e) Inserir novos empregados.

    //f) Remover empregados.

    //g) Mostrar relatório formatado com os nomes dos empregados e o valor, em ordem crescente
    //de nome de empregados. Gravar o relatório em arquivo texto (arquivo 2).

    //h) Ao terminar a execução do programa, salvar no arquivo de empregados (arquivo 1) os dados
    //atualizados dos empregados.

    public static void main(String[] args) {

        BancoDados bd = new BancoDados();

        InterfaceGrafica.mostrarTabela();

        System.out.println();

    }

}
